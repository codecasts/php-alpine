<?php
class PEAR_Installer_Role_Testf extends PEAR_Installer_Role_Common{}
