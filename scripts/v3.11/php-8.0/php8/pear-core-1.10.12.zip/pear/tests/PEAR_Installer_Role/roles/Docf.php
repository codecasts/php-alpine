<?php
class PEAR_Installer_Role_Docf extends PEAR_Installer_Role_Common{}
