<?php
class PEAR_Installer_Role_Funky extends PEAR_Installer_Role_Common{}
