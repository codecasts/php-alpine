<?php
class PEAR_Installer_Role_Nophp extends PEAR_Installer_Role_Common{}
