<?php
class PEAR_Installer_Role_Isphp extends PEAR_Installer_Role_Common{}
