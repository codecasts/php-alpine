<?php
class PEAR_Installer_Role_Noextsrc extends PEAR_Installer_Role_Common{}
