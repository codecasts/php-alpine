<?php
class PEAR_Installer_Role_Notphp extends PEAR_Installer_Role_Common{}
