<?php
class Test {}
?>
